"""
Lambda Authorizer for Admin APIs
Validates auth_token and checks admin permissions
"""

import os
import json
import time
import boto3
import jwt
from typing import Dict, Any, Optional

# Environment variables
REGION = os.environ.get("AWS_REGION", "us-east-1")
USERS_TABLE = os.environ.get('USERS_TABLE')
AUTH_SECRET = os.environ.get("AUTH_SECRET")
APP_JWT_ISS = os.environ.get("APP_JWT_ISS", "auth")
APP_JWT_AUD = os.environ.get("APP_JWT_AUD", "internal")

# DynamoDB setup
ddb = boto3.resource("dynamodb", region_name=REGION)
table = ddb.Table(USERS_TABLE)

def _now() -> int:
    return int(time.time())

def _get_profile(user_id: str) -> Optional[Dict[str, Any]]:
    try:
        r = table.get_item(Key={"user_id": user_id})
        return r.get("Item")
    except Exception as e:
        print("Error: "+ e)
        return None

def _verify_auth_token(auth_token: str) -> Optional[Dict[str, Any]]:
    """Verify auth token and return user profile if valid"""
    try:
        # Parse userId@jwt format
        if "@" not in auth_token:
            return None
       
        user_id, token = auth_token.split("@", 1)
        print(f"User ID: {user_id}, Token: {token}")
        # Verify JWT signature
        try:
            claims = jwt.decode(
                token,
                AUTH_SECRET,
                algorithms=["HS256"],
                audience=APP_JWT_AUD,
                issuer=APP_JWT_ISS,
                leeway=30,
                options={"verify_signature": True}
            )
            print(f"Claims: {json.dumps(claims)}")
            if claims.get("sub") != user_id:
                return None
        except Exception as e:
            print(f"Error decoding token: {str(e)}")
            return None
       
        # Get user profile from DB
        profile = _get_profile(user_id)
        if not profile:
            return None
       
        # Check token matches DB and isn't expired
        if profile.get("auth_token") != token:
            print(f"Token does not match DB")
            return None
       
        if _now() >= int(profile.get("auth_token_exp", 0)):
            print(f"Token expired")
            return None
       
        return profile
       
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Error verifying auth token: {str(e)}")
        return None

def generate_policy(effect: str, resource: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
    """Generate IAM policy for API Gateway"""
    if '/admin/' in resource:
        arn_parts = resource.split(':')
        api_gateway_arn = arn_parts[5].split('/')
        region     = arn_parts[3]
        account_id = arn_parts[4]
        api_id     = api_gateway_arn[0]
        stage      = api_gateway_arn[1]
        base = f"arn:aws:execute-api:{region}:{account_id}:{api_id}/{stage}"
        resource = f"{base}/*/api/v1/admin/*"
        
    policy = {
        "principalId": context.get("user_id", "user") if context else "user",
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": resource
                }
            ]
        }
    }
    
    if context:
        policy["context"] = context
    
    return policy

def lambda_handler(event, context):
    """Lambda Authorizer Handler"""
    # Extract token from Authorization header
    token = None
    auth_token = event.get("authorizationToken")
    if auth_token and auth_token.startswith("Bearer "):
        token = auth_token[7:]
    else:
        token = auth_header
    
    if not token:
        print("No authorization token provided")
        raise Exception("Unauthorized")
    
    # Verify token and get user profile
    profile = _verify_auth_token(token)
    if not profile:
        print("Invalid or expired token")
        raise Exception("Unauthorized")
    
    # Check if user is approved
    if profile.get("status") != "APPROVED":
        print(f"User not approved, status: {profile.get('status')}")
        return generate_policy("Deny", event.get("methodArn"))
    
    # For admin APIs, check if user has admin role
    method_arn = event.get("methodArn")
    if "/admin/" in method_arn:
        user_roles = profile.get("user_roles", [])
        if "ADMINISTRATOR" not in user_roles:
            print(f"User not admin, roles: {user_roles}")
            return generate_policy("Deny", method_arn)
    
    # Allow request and pass user context
    user_context = {
        "user_id": profile["user_id"],
        "email": profile.get("email", ""),
        "roles": json.dumps(profile.get("user_roles", [])),
        "status": profile.get("status", ""),
        "accessLevel": profile.get("accessLevel", "")
    }
    
    print(f"Access granted for user: {profile['user_id']}")
    policy = generate_policy("Allow", method_arn, user_context)
    print(policy)
    return policy

